package com.example.bt_retrofit.adapters;

import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter {
}
