package com.example.bt1;

public class Const {
    public static final String MY_USERNAME = "username";
    public static final String MY_IMAGES = "avatar";
}
